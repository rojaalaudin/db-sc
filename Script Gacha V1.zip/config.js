// config.js
module.exports = {
  BOT_TOKEN: "8403183111:AAH-Hl7aYRcn8KU_RY0cNxIH_ohP75u5P5U" // ganti dengan token dari @BotFather
};