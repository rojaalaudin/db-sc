const { Telegraf, Markup } = require("telegraf");
const { BOT_TOKEN } = require("./config");

if (!BOT_TOKEN || BOT_TOKEN.includes("ISI_TOKEN")) {
  console.error("❌ Harap isi BOT_TOKEN di config.js");
  process.exit(1);
}

const bot = new Telegraf(BOT_TOKEN);

// Developer info
const developer = {
  username: "https://t.me/AvailableWann", // ganti dengan username dev
  link: "https://t.me/USERNAME_DEVELOPER"
};

// State
const games = {};
const inputState = {};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function displayName(user) {
  return user.username ? `@${user.username}` : `ID:${user.id}`;
}
function formatParticipants(members) {
  return members.map((m, i) => `${i + 1}. ${m.username}`).join("\n");
}
function progressBar(seconds, total = 30, width = 12) {
  const ratio = Math.min(seconds / total, 1);
  const filled = Math.round(ratio * width);
  const empty = width - filled;
  return `🔄 Loading [${"#".repeat(filled)}${"-".repeat(empty)}] ${seconds}/${total}s`;
}

// ==================== START ====================
bot.start(async (ctx) => {
  const u = ctx.from;
  const uname = displayName(u);

  const welcome =
    `✨ ━━━━━━━ 〔 *BOT GACHA* 🎲 〕━━━━━━━ ✨\n\n` +
    `👋 Halo *${u.first_name || "kawan"}*!\n\n` +
    `🆔 *ID Kamu:* \`${u.id}\`\n` +
    `📛 *Username:* ${uname}\n\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `🎯 Dengan bot ini, kamu bisa:\n` +
    `• Membuat event gacha (undi pemenang)\n` +
    `• Mengatur jumlah peserta & pemenang\n` +
    `• Host punya kontrol penuh\n\n` +
    `⚡ *Ayo mulai keseruanmu sekarang!* ⚡`;

  await ctx.reply(welcome, {
    parse_mode: "Markdown",
    ...Markup.inlineKeyboard([
      [Markup.button.callback("🎲 Gacha", "create_gacha")],
      [Markup.button.callback("📖 Cara Menggunakan", "howto")],
      [Markup.button.url("👨‍💻 Developer", developer.link)]
    ])
  });
});

// ==================== HOWTO ====================
bot.action("howto", async (ctx) => {
  await ctx.answerCbQuery();
  const howto =
    `📖 *Cara Menggunakan Bot Gacha*\n\n` +
    `1) Klik tombol 🎲 Gacha.\n` +
    `2) Masukkan jumlah anggota.\n` +
    `3) Masukkan jumlah pemenang.\n` +
    `4) Peserta klik tombol *✅ Ikutan*.\n` +
    `5) Kalau slot penuh, tombol *🎯 Mulai Gacha* muncul.\n` +
    `6) Hanya host yang bisa mulai gacha.\n` +
    `7) Saat mulai, ada animasi loading 30 detik, lalu bot umumkan pemenang 🎉.`;
  await ctx.reply(howto, { parse_mode: "Markdown" });
});

// ==================== CREATE GACHA ====================
bot.action("create_gacha", async (ctx) => {
  inputState[ctx.from.id] = { step: "jumlah_anggota", chatId: ctx.chat.id };
  await ctx.answerCbQuery();
  await ctx.reply("📝 Masukkan jumlah *anggota*:", { parse_mode: "Markdown" });
});

// ==================== HANDLE INPUT ====================
bot.on("text", async (ctx) => {
  const state = inputState[ctx.from.id];
  if (!state) return;

  const input = parseInt(ctx.message.text.trim());
  if (isNaN(input) || input <= 0) {
    return ctx.reply("⚠️ Harap masukkan angka yang valid.");
  }

  if (state.step === "jumlah_anggota") {
    inputState[ctx.from.id].total = input;
    inputState[ctx.from.id].step = "jumlah_pemenang";
    return ctx.reply("🏆 Masukkan jumlah *pemenang*:", { parse_mode: "Markdown" });
  }

  if (state.step === "jumlah_pemenang") {
    if (input > inputState[ctx.from.id].total) {
      return ctx.reply("⚠️ Jumlah pemenang tidak boleh lebih banyak dari jumlah anggota.");
    }

    inputState[ctx.from.id].winners = input;

    const total = inputState[ctx.from.id].total;
    const winners = input;
    const hostId = ctx.from.id;

    games[state.chatId] = {
      host: hostId,
      total,
      winners,
      participants: [],
      messageId: null
    };

    const text = `🎲 *Gacha dimulai oleh ${displayName(ctx.from)}*\n\n📋 Peserta (0/${total})\n\nKlik tombol di bawah untuk ikut!`;

    const message = await ctx.reply(text, Markup.inlineKeyboard([
      [Markup.button.callback("✅ Ikutan", "join_gacha")]
    ]));

    games[state.chatId].messageId = message.message_id;

    delete inputState[ctx.from.id];
  }
});

// ==================== JOIN ====================
bot.action("join_gacha", async (ctx) => {
  const g = games[ctx.chat.id];
  if (!g) return ctx.answerCbQuery("⚠️ Tidak ada gacha aktif.");

  if (g.participants.find(p => p.id === ctx.from.id)) {
    return ctx.answerCbQuery("❌ Kamu sudah ikut.");
  }

  if (g.participants.length >= g.total) {
    return ctx.answerCbQuery("⚠️ Peserta sudah penuh.");
  }

  g.participants.push({ id: ctx.from.id, username: displayName(ctx.from) });

  let text = `🎲 *Gacha dimulai oleh ${displayName({id: g.host, username: ctx.from.username})}*\n\n📋 Peserta (${g.participants.length}/${g.total}):\n${formatParticipants(g.participants)}`;
  
  let buttons = [[Markup.button.callback("✅ Ikutan", "join_gacha")]];
  if (g.participants.length === g.total) {
    buttons = [[Markup.button.callback("🎯 Mulai Gacha", "start_gacha")]];
  }

  await ctx.telegram.editMessageText(ctx.chat.id, g.messageId, null, text, {
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: buttons }
  });

  ctx.answerCbQuery(`✅ ${displayName(ctx.from)} berhasil ikutan!`);
});

// ==================== START GACHA ====================
bot.action("start_gacha", async (ctx) => {
  const g = games[ctx.chat.id];
  if (!g) return ctx.answerCbQuery("⚠️ Tidak ada gacha aktif.");
  if (ctx.from.id !== g.host) return ctx.answerCbQuery("⚠️ Hanya host yang bisa mulai gacha.");

  await ctx.answerCbQuery();

  let msg = await ctx.reply("🔄 Loading [------------] 0/30s");

  for (let sec = 5; sec <= 30; sec += 5) {
    await sleep(5000);
    await ctx.telegram.editMessageText(ctx.chat.id, msg.message_id, null, progressBar(sec));
  }

  const shuffled = g.participants.sort(() => 0.5 - Math.random());
  const winners = shuffled.slice(0, g.winners);

  const result =
    `🎉 *HASIL GACHA* 🎉\n\n` +
    `👥 Total peserta: ${g.total}\n` +
    `🏆 Jumlah pemenang: ${g.winners}\n\n` +
    `🥳 Pemenang:\n${winners.map((w, i) => `${i + 1}. ${w.username}`).join("\n")}\n\n` +
    `🎯 Host: ${displayName({ id: g.host, username: ctx.from.username })}`;

  await ctx.telegram.editMessageText(ctx.chat.id, msg.message_id, null, result, {
    parse_mode: "Markdown"
  });

  delete games[ctx.chat.id];
});

bot.launch();
console.log("🤖 Bot gacha berjalan...");